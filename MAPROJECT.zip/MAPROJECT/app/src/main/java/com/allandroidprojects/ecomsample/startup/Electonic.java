package com.allandroidprojects.ecomsample.startup;

public class Electonic extends SuperClass {

    public Electonic()
    {

        super();
        offers.add(new Word("Desktop Computer", "New Apple iMac (27-inch Retina 5k display, 3.1GHz 6-core 8th-generation Intel", "Rs 120077.00"));
        offers.add(new Word("Samsung Phone", "Samsung Galaxy S10+ Plus G975F GSM Unlocked Smartphone Renewed)  Prism White", "Rs 87000.00"));
        offers.add(new Word("Camera Chips", "2 Pack 32GB Micro SD SDHC Memory Card Plus Adapter Class 10 U1 UHS-I V10 A1 Pro", "Rs 4600.00"));
        offers.add(new Word("Screen player", "Large Swivel Screen, 6 Hrs Long Lasting Built-in Battery, Region Free, Stereo Sound,", "Rs 15887.00"));
    }
}
