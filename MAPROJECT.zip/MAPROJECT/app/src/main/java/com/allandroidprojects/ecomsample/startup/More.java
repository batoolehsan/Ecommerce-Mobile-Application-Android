package com.allandroidprojects.ecomsample.startup;

public class More extends SuperClass {

    public More()
    {


       super();
        offers.add(new Word("Clutcher", "Parcelona French PLUME Small Brown Shell and Black Set of 2 Celluloid Tortoise Jaw Hair Claw Clip Clamp", "Rs 200.00"));
        offers.add(new Word("Kitchen Stuff", "Organic Bamboo Cooking Serving Utensil Set By Neet - 6 Piece Set | Spoon & Spatula Mix | Utensil Holder", "Rs 1499.00"));
    }
}
