package com.allandroidprojects.ecomsample.startup;

public class Book extends SuperClass {

    public Book()
    {

        super();
        offers.add(new Word("Notebook", "Notes on Startups, or How to Build the Future: Peter Thiel (Author), Blake Masters (Author)", "Rs 180.00"));
        offers.add(new Word("Diary Notebook", "Great Niche Ideas for No Content and Low Content Books: Work from Home and Make", "Rs 270.00"));
        offers.add(new Word("Novel", "Duet (A Genetically Modified Novel Book 2) Electromagnetic pulses began a catastrophe changed", "Rs 879.00"));

    }

}
