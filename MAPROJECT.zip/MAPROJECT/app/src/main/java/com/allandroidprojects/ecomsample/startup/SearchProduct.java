package com.allandroidprojects.ecomsample.startup;

import com.allandroidprojects.ecomsample.R;

import java.util.ArrayList;
import java.util.List;

public class SearchProduct {

    public final List<Item> productList;

    public SearchProduct()
    {

        productList = new ArrayList<>();

        //offer products;
        productList.add(new Item("Bass Guitar", "Classical guitar  type of chordophone, traditionally constructed from wood and strung", "15999.00",
        R.drawable.offer_quitar, "https://tse3.mm.bing.net/th?id=OIP.hmUikDWx-98PZS4BhxVXWwHaHa&pid=Api&P=0"));

        productList.add(new Item("Study Glasses", "Peter Jones Anti-Reflective Round Unisex Sunglasses - (NA90|48|White Color Lens)", "899.00",
                R.drawable.offer_glasses, "https://tse3.mm.bing.net/th?id=OIP.8oEvS-e1KTB_avAsGDKqNAHaEo&pid=Api&P=0"));

        productList.add(new Item("Table Clock","Density Collection Digital Clocks Battery Powered Led 7 Colors Changing Night Light Star Sky Digital Led", "400.00",
                R.drawable.offer_clock, "https://tse1.mm.bing.net/th?id=OIP.lUoDFixLLRN2K5B3OpQ_9AHaIM&pid=Api&P=0"));


        productList.add(new Item("Sewing Machine", "Brother Sewing Machine, XM2701, Lightweight Sewing Machine with 27 Stitches", "15000.00",
                R.drawable.offer_sewing_machine, "https://s1.cdn.autoevolution.com/images/news/gallery/mercedes-sewing-machine-is-a-modern-version-of-something-classic_4.jpg"));

        productList.add(new Item("Mashroom Lamp","Modernluci Wall Sconce LED Wall Light Modern Plug in Bedroom Lamp Dark Grey", "4549.00",
                R.drawable.offer_lump, "https://tse1.mm.bing.net/th?id=OIP.tbR6V6wEqvhy_cWMFy5WWAHaJP&pid=Api&P=0"));

        productList.add(new Item("Camera Chip", "Kodak PIXPRO Astro Zoom AZ401-BK 16MP Digital Camera with 40X Optical Zoom and 3 LCD (Black)", "3200.00",
                R.drawable.offer_camera, "https://sociable.co/wp-content/uploads/2010/12/SDcards_2.png"));


        // Electronics

        productList.add(new Item("Desktop Computer", "New Apple iMac (27-inch Retina 5k display, 3.1GHz 6-core 8th-generation Intel", "120077.00",
                R.drawable.electronic_desktop_computer, "https://www.macworld.com/wp-content/uploads/2021/03/27in-imac-2020-studio-01-100854622-orig-1.jpg"));

        productList.add(new Item("Samsung Phone", "Samsung Galaxy S10+ Plus G975F GSM Unlocked Smartphone Renewed)  Prism White 128GB", "87000.00",
                R.drawable.electornic_samsung_phone, "https://dr3tjvhkhrb1b.cloudfront.net/592080_dca61778-d4bc-4bb3-9fa7-c7375a1ff596_1080x1350.jpg"));


        productList.add(new Item("Screen player", "Large Swivel Screen, 6 Hrs Long Lasting Built-in Battery, Region Free, Stereo Sound,", "15887.00",
                R.drawable.electronic_screen_player, "https://static.pexels.com/photos/213384/pexels-photo-213384-medium.jpeg"));



        // LIfeStyle
        productList.add(new Item("Red Party Dress", "VETIOR Women's Long Sleeve Scoop Neck Casual Flared Midi Swing Dress", "3150.00",
                R.drawable.lifestyle_red_dress, "https://crayon.pk/wp-content/uploads/2017/10/Beautiful-Red-Pakistani-Party-Dresses-2017.jpg"));

        productList.add(new Item("Spring Outdoor cloth", "Floerns Women's Summer Chiffon Sleeveless Party Dress has sleeveless"," 1580.00",
                R.drawable.lifestyle_spring_white_dress, "https://tse4.mm.bing.net/th?id=OIP.Ig8ZQ2E36XyaBg0Zw1t7SQHaLG&pid=Api&P=0"));

        productList.add(new Item("Black Bow Tie", "Mens Classic Pre-Tied Satin FormalTuxedo Bowtie Adjustable Length Large", "399.00",
                R.drawable.lifestyle_black_bow_tie, "https://ae01.alicdn.com/kf/HTB1e78aNXXXXXaxXFXXq6xXFXXX2/BS704L-Black-Houndstooth-Bowtie-Men-Cotton-Party-Classic-Wedding-Self-Bow-Tie.jpg"));


        //Home Appliances
        productList.add(new Item("Double White Bed Sheet", "Regalo HideAway Double Sided Bed Rail Guard, with Reinforced Anchor Safety System pillow", "1500.00",
                R.drawable.home_double_bed, "https://ii1.pepperfry.com/media/catalog/product/s/o/1100x1210/solid-90-x-108-inch-cotton-190-tc-queen-size-duvet-cover-by-mark-home-solid-90-x-108-inch-cotton-190-u9wsna.jpg"));

        productList.add(new Item("Mountain Frame", "Abstract Mountain in Daytime Canvas Prints Wall Art Paintings Abstract Geometry Wall", "750.00",
                R.drawable.home_drawing_art, "https://tse1.mm.bing.net/th?id=OIP.aVGYb3c01YZC8fsAJaDSugHaHa&pid=Api&P=0"));

        productList.add(new Item("Sofa pillows", "Bikuer Printed Dark Blue Sofa Cover Stretch Couch Cover Sofa Slipcovers Couch", "870.00",
                R.drawable.home_sofa_pillow, "https://i5.walmartimages.com/asr/3a7ccca4-9b98-4f1c-9aa2-a7aa20d21717.c0bcb65839723b73b5551367522485dc.jpeg"));





        //Book

        productList.add(new Item("Notebook", "Notes on Startups, or How to Build the Future: Peter Thiel (Author), Blake Masters (Author)",  "180.00",
                R.drawable.book_happy, "https://cdn.notonthehighstreet.com/fs/32/5e/01cd-2912-4d07-b80d-47640ba62799/original_whatever-make-your-soul-happy-notebook-personalised.jpg"));

        productList.add(new Item("Diary Notebook", "Great Niche Ideas for No Content and Low Content Books: Work from Home and Make Money Online", "270.00",
                R.drawable.book_diary_notebook, "https://ae01.alicdn.com/kf/HTB1ZVmAXIfrK1Rjy0Fmq6xhEXXav/2019-Cute-Kawaii-Notebook-Hook-Star-Leather-Cartoon-Lovely-Journal-Diary-Planner-for-Kids-Gift-Notepad.jpg"));

        productList.add(new Item("Novel", "Duet (A Genetically Modified Novel Book 2) Electromagnetic pulses began a catastrophe changed", "879.00",
                R.drawable.home_holy_books, "https://tse4.mm.bing.net/th?id=OIP.wsLTs7V6nrfpII0H4Q7SGAHaFE&pid=Api&P=0"));



        // more
        productList.add(new Item("Clutcher", "Parcelona French PLUME Small Brown Shell and Black Set of 2 Celluloid Tortoise Jaw Hair Claw Clip Clamp", "200.00",
                R.drawable.more_clutcher, "https://tse2.mm.bing.net/th?id=OIP.Pe28wt61eydnyJwIq7RcKQHaHa&pid=Api&P=0"));

        productList.add(new Item("Kitchen Stuff", "Organic Bamboo Cooking Serving Utensil Set By Neet - 6 Piece Set | Spoon & Spatula Mix | Utensil Holder", "1499.00",
                R.drawable.more_cooking_stuff, "https://tse4.mm.bing.net/th?id=OIP.ePvSxJs7n9cC05J7OkJsXgHaHa&pid=Api&P=0"));


    }// end of constructor




    public List<Item> getProductList(){
        return productList;
    }

}
